/* App.jsx - Pemuda Panca Marga Kota Bandung (single-file app) */
/* NOTE: This is the same code prepared earlier (client-side email/password demo). */
import React, { useState, useEffect } from "react";

const MAROON = "#6e1e2b";
const ACCENT = "#8b2430";

// Helper: SHA-256 hashing using Web Crypto API
async function hashString(str) {
  const enc = new TextEncoder();
  const data = enc.encode(str);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

export default function PemudaPancaMargaBandungApp() {
  const [route, setRoute] = useState("home");

  // Auth state
  const [isAdmin, setIsAdmin] = useState(false);
  const [authEmail, setAuthEmail] = useState("");
  const [authPwd, setAuthPwd] = useState("");
  const [authError, setAuthError] = useState("");
  const [isRegistering, setIsRegistering] = useState(false);

  // Core data
  const [events, setEvents] = useState(() => JSON.parse(localStorage.getItem("ppm_events") || "null") || [
    { id: 1, title: "Pelatihan Kepemimpinan Dasar", date: "2025-11-15", location: "Balai Kota Bandung", description: "Pelatihan kader dasar untuk pengurus muda." },
    { id: 2, title: "Bakti Sosial: Donor dan Bersih-Bersih", date: "2025-12-06", location: "Lapangan Bandung", description: "Aksi bersih-bersih dan donor darah." },
  ]);

  const [gallery, setGallery] = useState(() => JSON.parse(localStorage.getItem("ppm_gallery") || "null") || [
    { id: 1, url: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=800&q=60", caption: "Aksi sosial" },
    { id: 2, url: "https://images.unsplash.com/photo-1520975607535-89b3b8d6f7f6?w=800&q=60", caption: "Pelatihan" },
  ]);

  const [news, setNews] = useState(() => JSON.parse(localStorage.getItem("ppm_news") || "null") || [
    { id: 1, title: "PPM Bandung Ikut Serta di Karnaval Kota", date: "2025-09-10", excerpt: "PPM tampil semarak...", content: "Detail kegiatan diisi di sini." },
  ]);

  const [org, setOrg] = useState(() => JSON.parse(localStorage.getItem("ppm_org") || "null") || ({
    visi: "Mewujudkan generasi muda berintegritas dan berdaya.",
    misi: ["Pendidikan karakter", "Pelatihan & pengembangan", "Aksi sosial terencana"],
    structure: [
      { role: "Ketua", name: "Budi Santoso" },
      { role: "Wakil Ketua", name: "Siti Aminah" },
      { role: "Sekretaris", name: "Andi Wijaya" },
    ],
    history: `Pemuda Panca Marga (PPM) adalah organisasi kepemudaan yang menghimpun putra-putri purnawirawan... (tuliskan sejarah lengkap di sini).`,
  }));

  // Persist changes
  useEffect(() => { localStorage.setItem("ppm_events", JSON.stringify(events)); }, [events]);
  useEffect(() => { localStorage.setItem("ppm_gallery", JSON.stringify(gallery)); }, [gallery]);
  useEffect(() => { localStorage.setItem("ppm_news", JSON.stringify(news)); }, [news]);
  useEffect(() => { localStorage.setItem("ppm_org", JSON.stringify(org)); }, [org]);

  // Admin account storage key: ppm_admin -> {email, passwordHash}
  const getAdminAccount = () => JSON.parse(localStorage.getItem("ppm_admin") || "null");
  const setAdminAccount = (acct) => localStorage.setItem("ppm_admin", JSON.stringify(acct));
  const removeAdminAccount = () => localStorage.removeItem("ppm_admin");

  // Auth actions
  const handleRegister = async () => {
    setAuthError("");
    if (!authEmail || !authPwd) { setAuthError("Isi email dan password."); return; }
    const existing = getAdminAccount();
    if (existing) { setAuthError("Akun admin sudah ada. Hapus akun dulu jika ingin mendaftar ulang."); return; }
    const hash = await hashString(authPwd);
    setAdminAccount({ email: authEmail.toLowerCase(), passwordHash: hash });
    setAuthEmail(""); setAuthPwd("");
    setIsRegistering(false);
    alert("Akun admin terdaftar. Silakan login.");
  };

  const handleLogin = async () => {
    setAuthError("");
    if (!authEmail || !authPwd) { setAuthError("Isi email dan password."); return; }
    const existing = getAdminAccount();
    if (!existing) { setAuthError("Belum ada akun admin terdaftar. Silakan registrasi dulu."); return; }
    const hash = await hashString(authPwd);
    if (existing.email === authEmail.toLowerCase() && existing.passwordHash === hash) {
      setIsAdmin(true);
      setAuthEmail(""); setAuthPwd("");
      setAuthError("");
    } else {
      setAuthError("Email atau password salah.");
    }
  };

  const handleLogout = () => { setIsAdmin(false); };

  // Admin utility to delete account (dangerous)
  const handleDeleteAdminAccount = () => {
    if (!confirm("Hapus akun admin dari localStorage? Tindakan ini tidak bisa dibatalkan.")) return;
    removeAdminAccount();
    setIsAdmin(false);
    alert("Akun admin dihapus. Silakan registrasi ulang jika perlu.");
  };

  // Admin data management
  const addEvent = (e) => setEvents((prev) => [...prev, { ...e, id: Date.now() }]);
  const deleteEvent = (id) => setEvents((prev) => prev.filter((x) => x.id !== id));

  const addImage = (img) => setGallery((prev) => [...prev, { ...img, id: Date.now() }]);
  const deleteImage = (id) => setGallery((prev) => prev.filter((x) => x.id !== id));

  const addNews = (n) => setNews((prev) => [...prev, { ...n, id: Date.now() }]);
  const deleteNews = (id) => setNews((prev) => prev.filter((x) => x.id !== id));

  // Small UI components
  function Nav() {
    const [open, setOpen] = useState(false);
    return (
      <header className="bg-white shadow-sm sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full" style={{ background: MAROON, color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700 }}>PPM</div>
              <div>
                <div className="font-bold text-lg">Pemuda Panca Marga</div>
                <div className="text-xs text-gray-500">Kota Bandung</div>
              </div>
            </div>

            <nav className="hidden md:flex gap-6 items-center text-sm">
              <button className="hover:underline" onClick={() => setRoute("home")}>Beranda</button>
              <button className="hover:underline" onClick={() => setRoute("news")}>Berita</button>
              <button className="hover:underline" onClick={() => setRoute("events")}>Acara</button>
              <button className="hover:underline" onClick={() => setRoute("gallery")}>Galeri</button>
              <button className="hover:underline" onClick={() => setRoute("about")}>Sejarah & Struktur</button>
              <button className="hover:underline" onClick={() => setRoute("contact")}>Kontak</button>
              {isAdmin ? (
                <>
                  <button onClick={() => setRoute("admin")} className="px-3 py-1 rounded-md text-sm border border-gray-200">Admin Panel</button>
                  <button onClick={handleLogout} className="px-3 py-1 rounded-md text-sm text-red-600">Logout</button>
                </>
              ) : (
                <>
                  <button onClick={() => { setIsRegistering(false); setRoute("home"); }} className="px-3 py-1 rounded-md text-sm">Masuk/Daftar</button>
                </>
              )}
            </nav>

            <div className="md:hidden flex items-center">
              <button onClick={() => setOpen(!open)} className="p-2 rounded-md border">☰</button>
            </div>
          </div>
        </div>
      </header>
    );
  }

  const Section = ({ children, className = "" }) => (
    <section className={`max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 ${className}`}>{children}</section>
  );

  // Pages
  function Home() {
    return (
      <>
        <Section>
          <div className="bg-gradient-to-r" style={{ background: `linear-gradient(90deg, ${MAROON} 0%, ${ACCENT} 100%)` }}>
            <div className="max-w-6xl mx-auto px-6 py-12 text-white rounded-lg shadow-lg">
              <h1 className="text-3xl sm:text-4xl font-extrabold">Pemuda Panca Marga — Kota Bandung</h1>
              <p className="mt-3 max-w-2xl">Bersatu, Berkarya, Berbakti. Kami memfasilitasi pemuda untuk berkontribusi pada masyarakat lewat pelatihan, bakti sosial, dan pelestarian sejarah.</p>
              <div className="mt-6 flex gap-3 flex-wrap">
                <button onClick={() => setRoute("events")} className="px-4 py-2 bg-white text-maroon rounded-md font-medium" style={{ color: MAROON }}>Lihat Acara</button>
                <button onClick={() => setRoute("news")} className="px-4 py-2 border border-white text-white rounded-md">Berita & Kegiatan</button>
              </div>
            </div>
          </div>
        </Section>

        <Section className="grid md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="font-semibold">Visi</h3>
            <p className="mt-2 text-sm">{org.visi}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="font-semibold">Misi</h3>
            <ul className="mt-2 text-sm list-disc ml-5">
              {org.misi.map((m, i) => (<li key={i}>{m}</li>))}
            </ul>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="font-semibold">Kontak Cepat</h3>
            <p className="mt-2 text-sm">Email: info@ppmbandung.or.id</p>
            <p className="text-sm">Telp: +62 22 0000 0000</p>
          </div>
        </Section>

        <Section>
          <h3 className="text-xl font-semibold mb-4">Acara Mendatang</h3>
          <div className="grid md:grid-cols-2 gap-4">
            {events.slice(0, 4).map((ev) => (
              <article key={ev.id} className="bg-white p-4 rounded-lg shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-semibold">{ev.title}</h4>
                    <p className="text-sm text-gray-600">{ev.date} • {ev.location}</p>
                    <p className="mt-2 text-sm text-gray-700">{ev.description}</p>
                  </div>
                  <button onClick={() => setRoute("events")} className="text-sm text-maroon font-medium" style={{ color: MAROON }}>Detail</button>
                </div>
              </article>
            ))}
          </div>
        </Section>
      </>
    );
  }

  function NewsPage() {
    return (
      <Section>
        <h2 className="text-2xl font-bold mb-4">Berita & Kegiatan</h2>
        <div className="grid md:grid-cols-2 gap-4">
          {news.map((n) => (
            <article key={n.id} className="bg-white p-4 rounded-lg shadow">
              <h4 className="font-semibold">{n.title}</h4>
              <p className="text-sm text-gray-500">{n.date}</p>
              <p className="mt-2 text-sm text-gray-700">{n.excerpt}</p>
              <details className="mt-2 text-sm text-gray-700">
                <summary className="cursor-pointer text-indigo-600">Baca selengkapnya</summary>
                <p className="mt-2">{n.content}</p>
              </details>
            </article>
          ))}
        </div>
      </Section>
    );
  }

  function EventsPage() {
    return (
      <Section>
        <h2 className="text-2xl font-bold mb-4">Daftar Acara</h2>
        <div className="space-y-4">
          {events.map((ev) => (
            <div key={ev.id} className="bg-white p-4 rounded-lg shadow flex justify-between items-start">
              <div>
                <h4 className="font-semibold">{ev.title}</h4>
                <p className="text-sm text-gray-500">{ev.date} • {ev.location}</p>
                <p className="mt-2 text-sm text-gray-700">{ev.description}</p>
              </div>
              <button className="text-indigo-600">Daftar</button>
            </div>
          ))}
        </div>
      </Section>
    );
  }

  function GalleryPage() {
    return (
      <Section>
        <h2 className="text-2xl font-bold mb-4">Galeri</h2>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
          {gallery.map((g) => (
            <figure key={g.id} className="bg-white rounded-lg overflow-hidden shadow">
              <img src={g.url} alt={g.caption || "galeri"} className="w-full h-48 object-cover" />
              {g.caption && <figcaption className="p-2 text-sm">{g.caption}</figcaption>}
            </figure>
          ))}
        </div>
      </Section>
    );
  }

  function AboutPage() {
    return (
      <Section>
        <h2 className="text-2xl font-bold mb-4">Sejarah & Struktur Organisasi</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="font-semibold">Sejarah</h3>
            <p className="mt-2 text-sm text-gray-700">{org.history}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="font-semibold">Struktur Organisasi</h3>
            <ul className="mt-2 text-sm">
              {org.structure.map((s, i) => (
                <li key={i}><strong>{s.role}:</strong> {s.name}</li>
              ))}
            </ul>
          </div>
        </div>
      </Section>
    );
  }

  function ContactPage() {
    const [form, setForm] = useState({ name: "", email: "", message: "" });
    const [submitted, setSubmitted] = useState(false);
    const handleSubmit = (e) => {
      e.preventDefault();
      const msgs = JSON.parse(localStorage.getItem("ppm_messages") || "[]");
      msgs.push({ id: Date.now(), ...form });
      localStorage.setItem("ppm_messages", JSON.stringify(msgs));
      setSubmitted(true);
      setForm({ name: "", email: "", message: "" });
    };

    return (
      <Section>
        <h2 className="text-2xl font-bold mb-4">Kontak & Pendaftaran Anggota</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow">
            {submitted && <div className="mb-3 text-green-600">Terima kasih! Pesan Anda telah dikirim.</div>}
            <label className="block text-sm font-medium">Nama</label>
            <input className="mt-1 w-full border p-2 rounded" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            <label className="block text-sm font-medium mt-3">Email</label>
            <input type="email" className="mt-1 w-full border p-2 rounded" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
            <label className="block text-sm font-medium mt-3">Pesan / Alasan Daftar</label>
            <textarea className="mt-1 w-full border p-2 rounded" rows={4} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} required />
            <button type="submit" className="mt-4 px-4 py-2 rounded" style={{ background: MAROON, color: "white" }}>Kirim / Daftar</button>
          </form>

          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="font-semibold">Informasi</h3>
            <p className="mt-2 text-sm">Alamat: Jl. Contoh No.123, Bandung</p>
            <p className="text-sm">Email: info@ppmbandung.or.id</p>
            <p className="text-sm">Telp: +62 22 0000 0000</p>
            <div className="mt-4">
              <h4 className="font-semibold">Catatan</h4>
              <p className="text-sm">Formulir ini saat ini menyimpan data di browser (demo). Jika ingin terima pendaftaran secara real, saya bisa hubungkan ke Firebase atau backend lain.</p>
            </div>
          </div>
        </div>
      </Section>
    );
  }

  function AdminPanel() {
    const [ev, setEv] = useState({ title: "", date: "", location: "", description: "" });
    const [imgUrl, setImgUrl] = useState("");
    const [imgCaption, setImgCaption] = useState("");
    const [nw, setNw] = useState({ title: "", date: "", excerpt: "", content: "" });

    return (
      <Section>
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">Admin Panel</h2>
          <div className="flex gap-2">
            <button onClick={handleDeleteAdminAccount} className="px-3 py-1 rounded border text-sm">Hapus Akun Admin</button>
            <button onClick={handleLogout} className="px-3 py-1 rounded bg-red-600 text-white">Logout</button>
          </div>
        </div>

        <div className="mt-6 grid md:grid-cols-3 gap-6">
          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-semibold mb-2">Tambah Acara</h3>
            <input className="w-full border p-2 rounded mb-2" placeholder="Judul" value={ev.title} onChange={(e) => setEv({ ...ev, title: e.target.value })} />
            <input className="w-full border p-2 rounded mb-2" placeholder="Tanggal (YYYY-MM-DD)" value={ev.date} onChange={(e) => setEv({ ...ev, date: e.target.value })} />
            <input className="w-full border p-2 rounded mb-2" placeholder="Lokasi" value={ev.location} onChange={(e) => setEv({ ...ev, location: e.target.value })} />
            <textarea className="w-full border p-2 rounded mb-2" placeholder="Deskripsi singkat" value={ev.description} onChange={(e) => setEv({ ...ev, description: e.target.value })} />
            <button onClick={() => { addEvent(ev); setEv({ title: "", date: "", location: "", description: "" }); }} className="px-3 py-2 rounded" style={{ background: MAROON, color: "white" }}>Tambah</button>
          </div>

          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-semibold mb-2">Tambah Gambar</h3>
            <input className="w-full border p-2 rounded mb-2" placeholder="URL gambar" value={imgUrl} onChange={(e) => setImgUrl(e.target.value)} />
            <input className="w-full border p-2 rounded mb-2" placeholder="Caption (opsional)" value={imgCaption} onChange={(e) => setImgCaption(e.target.value)} />
            <button onClick={() => { addImage({ url: imgUrl, caption: imgCaption }); setImgUrl(""); setImgCaption(""); }} className="px-3 py-2 rounded" style={{ background: MAROON, color: "white" }}>Tambah</button>
          </div>

          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-semibold mb-2">Tambah Berita</h3>
            <input className="w-full border p-2 rounded mb-2" placeholder="Judul" value={nw.title} onChange={(e) => setNw({ ...nw, title: e.target.value })} />
            <input className="w-full border p-2 rounded mb-2" placeholder="Tanggal" value={nw.date} onChange={(e) => setNw({ ...nw, date: e.target.value })} />
            <input className="w-full border p-2 rounded mb-2" placeholder="Ringkasan" value={nw.excerpt} onChange={(e) => setNw({ ...nw, excerpt: e.target.value })} />
            <textarea className="w-full border p-2 rounded mb-2" placeholder="Konten" value={nw.content} onChange={(e) => setNw({ ...nw, content: e.target.value })} />
            <button onClick={() => { addNews(nw); setNw({ title: "", date: "", excerpt: "", content: "" }); }} className="px-3 py-2 rounded" style={{ background: MAROON, color: "white" }}>Tambah</button>
          </div>
        </div>

        <div className="mt-6 grid md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded shadow">
            <h4 className="font-semibold mb-2">Acara Saat Ini</h4>
            <ul className="text-sm space-y-2">
              {events.map((e) => (
                <li key={e.id} className="flex justify-between items-center">
                  <span>{e.title}</span>
                  <button onClick={() => deleteEvent(e.id)} className="text-red-600 text-sm">Hapus</button>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-white p-4 rounded shadow">
            <h4 className="font-semibold mb-2">Galeri</h4>
            <ul className="text-sm space-y-2">
              {gallery.map((g) => (
                <li key={g.id} className="flex justify-between items-center">
                  <span className="truncate max-w-xs">{g.caption || g.url}</span>
                  <button onClick={() => deleteImage(g.id)} className="text-red-600 text-sm">Hapus</button>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-white p-4 rounded shadow">
            <h4 className="font-semibold mb-2">Berita</h4>
            <ul className="text-sm space-y-2">
              {news.map((n) => (
                <li key={n.id} className="flex justify-between items-center">
                  <span className="truncate max-w-xs">{n.title}</span>
                  <button onClick={() => deleteNews(n.id)} className="text-red-600 text-sm">Hapus</button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-6 bg-white p-4 rounded shadow">
          <h4 className="font-semibold mb-2">Edit Profil Organisasi</h4>
          <label className="text-sm">Visi</label>
          <textarea className="w-full border p-2 rounded mb-2" value={org.visi} onChange={(e) => setOrg({ ...org, visi: e.target.value })} />
          <label className="text-sm">Sejarah</label>
          <textarea className="w-full border p-2 rounded mb-2" rows={4} value={org.history} onChange={(e) => setOrg({ ...org, history: e.target.value })} />
          <label className="text-sm">Struktur (JSON array: [{"role":"...","name":"..."}])</label>
          <textarea className="w-full border p-2 rounded mb-2" rows={3} value={JSON.stringify(org.structure)} onChange={(e) => { try { const parsed = JSON.parse(e.target.value); setOrg({ ...org, structure: parsed }); } catch (err) {} }} />
        </div>
      </Section>
    );
  }

  // Authentication UI (login/register)
  if (!isAdmin && (route === "admin" || route === "home") && (isRegistering || authEmail || authPwd)) {
    // show auth modal-like section without blocking navigation
  }

  function AuthBox() {
    const existing = getAdminAccount();
    return (
      <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-40">
        <div className="bg-white p-6 rounded-lg w-80 shadow-lg">
          <h3 className="font-semibold text-lg mb-3">{isRegistering ? "Registrasi Admin" : "Login Admin"}</h3>
          <label className="text-sm">Email</label>
          <input className="w-full border p-2 rounded mb-2" value={authEmail} onChange={(e) => setAuthEmail(e.target.value)} />
          <label className="text-sm">Password</label>
          <input type="password" className="w-full border p-2 rounded mb-3" value={authPwd} onChange={(e) => setAuthPwd(e.target.value)} />
          {authError && <div className="text-red-600 text-sm mb-2">{authError}</div>}
          <div className="flex gap-2">
            {isRegistering ? (
              <button onClick={handleRegister} className="px-3 py-2 rounded" style={{ background: MAROON, color: "white" }}>Daftar</button>
            ) : (
              <button onClick={handleLogin} className="px-3 py-2 rounded" style={{ background: MAROON, color: "white" }}>Masuk</button>
            )}
            <button onClick={() => { setIsRegistering(!isRegistering); setAuthError(""); }} className="px-3 py-2 rounded border">{isRegistering ? "Sudah punya akun?" : "Daftar"}</button>
            <button onClick={() => { setAuthEmail(""); setAuthPwd(""); setAuthError(""); setIsRegistering(false); }} className="px-3 py-2 rounded border">Tutup</button>
          </div>
          <div className="mt-3 text-xs text-gray-500">Catatan: Ini autentikasi disimpan di browser (demo). Untuk produksi, gunakan backend nyata.</div>
          {!existing && <div className="mt-2 text-sm text-amber-600">Belum ada akun admin — registrasi diperlukan.</div>}
        </div>
      </div>
    );
  }

  // Render
  return (
    <div className="min-h-screen bg-gray-100 text-gray-800">
      <Nav />

      {/* Auth modal trigger: show when route=admin and not logged in */}
      {route === "admin" && !isAdmin && <AuthBox />}

      <main className="pt-6 pb-12">
        {route === "home" && <Home />}
        {route === "news" && <NewsPage />}
        {route === "events" && <EventsPage />}
        {route === "gallery" && <GalleryPage />}
        {route === "about" && <AboutPage />}
        {route === "contact" && <ContactPage />}
        {route === "admin" && isAdmin && <AdminPanel />}
      </main>

      <footer className="bg-white border-t py-6">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-sm text-gray-600 flex flex-col md:flex-row justify-between items-center gap-3">
          <div>© {new Date().getFullYear()} Pemuda Panca Marga Kota Bandung</div>
          <div>Designed: modern • maroon theme • responsive</div>
        </div>
      </footer>
    </div>
  );
}
