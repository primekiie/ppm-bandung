# PPM Bandung — Website (ppm-bandung)

Project generated for *Pemuda Panca Marga Kota Bandung*.

## Fitur
- Tema modern & elegan (maroon)
- Responsif (mobile-first)
- Halaman: Beranda, Berita, Acara, Galeri, Sejarah & Struktur, Kontak / Pendaftaran Anggota
- Admin CMS (email/password client-side demo) untuk mengelola acara, galeri, berita, dan profil organisasi
- Data disimpan di `localStorage` (demo). Untuk produksi, integrasikan backend (Firebase / Supabase / custom API).
- Deployment-ready for Netlify & Vercel (see config files)

## Cara Jalankan (lokal)
1. Pastikan Node.js & npm terpasang.
2. Clone atau unzip project, lalu:
```bash
npm install
npm run dev
```
3. Buka `http://localhost:5173` (atau URL yang ditampilkan terminal).

## Build & Deploy
Build:
```bash
npm run build
```
Deploy:
- **Netlify**: connect repo → build command `npm run build` → publish `dist`. `netlify.toml` sudah termasuk.
- **Vercel**: import project → build command `npm run build` → output directory `dist`. `vercel.json` sudah termasuk.

## Tailwind
Project menggunakan kelas Tailwind. Jika ingin menghilangkan Tailwind, ganti `src/index.css` dan kelas pada komponen.

## Catatan Keamanan
- Autentikasi admin saat ini disimpan di browser (hashed). Ini hanya untuk demo/test. Untuk produksi gunakan Firebase Auth atau server-side auth.
- Data juga di `localStorage`. Untuk persistensi yang aman gunakan database (Firestore / Supabase / MySQL + API).

## Struktur
```
ppm-bandung/
  index.html
  package.json
  vite.config.js
  tailwind.config.cjs
  postcss.config.cjs
  netlify.toml
  vercel.json
  README.md
  src/
    main.jsx
    index.css
    App.jsx
```

Jika mau, saya bisa:
- Integrasikan Firebase Auth + Firestore,
- Pisahkan komponen menjadi folder `src/components`,
- Langsung buat repo GitHub dan push (kamu perlu memberikan akses/token or push locally).

